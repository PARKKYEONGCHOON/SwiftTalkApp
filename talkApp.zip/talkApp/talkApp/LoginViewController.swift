//
//  LoginViewController.swift
//  talkApp
//
//  Created by 박경춘 on 2023/03/08.
//

import UIKit
import Firebase

class LoginViewController: UIViewController {
    
    @IBOutlet var Email: UITextField!
    @IBOutlet var Password: UITextField!
    @IBOutlet var LogInButton: UIButton!
    @IBOutlet var SignUpButton: UIButton!
    
    let remoteconfig = RemoteConfig.remoteConfig()
    var color : String!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        try! Auth.auth().signOut()
        
        let statusBar = UIView()
        self.view.addSubview(statusBar)
        statusBar.snp.makeConstraints{ (m) in
            m.right.top.left.equalTo(self.view)
            m.height.equalTo(20)
        }
        
        color = remoteconfig["splash_background"].stringValue
        
        statusBar.backgroundColor = UIColor(hex: color)
        LogInButton.backgroundColor = UIColor(hex: color)
        SignUpButton.backgroundColor = UIColor(hex: color)
        
        
        SignUpButton.addTarget(self, action: #selector(presentSignUp), for: .touchUpInside)
        LogInButton.addTarget(self, action: #selector(logInEvent), for: .touchUpInside)
        
        Auth.auth().addStateDidChangeListener { (auth,user) in
            
            if(user != nil) {
                let view = self.storyboard?.instantiateViewController(withIdentifier: "MainViewTabbarController") as! UITabBarController
                
                self.present(view, animated: true, completion: nil)
            }
            
        }
        
    }
    
    @objc func logInEvent(){
        
        Auth.auth().signIn(withEmail: Email.text!, password: Password.text!) { (user, error) in
            if(error != nil){
                let alert = UIAlertController(title: "에러", message: error.debugDescription, preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "확인", style: UIAlertAction.Style.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
            }
        }
        
    }
    
    
    @objc func presentSignUp(){
        let view = self.storyboard?.instantiateViewController(withIdentifier: "SignUpViewController") as! SignUpViewController
        
        self.present(view, animated: true, completion: nil)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
