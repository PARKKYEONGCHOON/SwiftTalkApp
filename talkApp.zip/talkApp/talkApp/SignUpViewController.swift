//
//  SignUpViewController.swift
//  talkApp
//
//  Created by 박경춘 on 2023/03/09.
//

import UIKit
import Firebase
import FirebaseStorage

class SignUpViewController: UIViewController, UINavigationControllerDelegate, UIImagePickerControllerDelegate {

    @IBOutlet var Email: UITextField!
    @IBOutlet var Password: UITextField!
    @IBOutlet var Name: UITextField!
    @IBOutlet var SignUp: UIButton!
    @IBOutlet var Cancel: UIButton!
    
    @IBOutlet var ImageView: UIImageView!
    
    let remoteconfig = RemoteConfig.remoteConfig()
    var color : String!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let statusBar = UIView()
        self.view.addSubview(statusBar)
        statusBar.snp.makeConstraints{ (m) in
            m.right.top.left.equalTo(self.view)
            m.height.equalTo(20)
        }
        
        color = remoteconfig["splash_background"].stringValue
        statusBar.backgroundColor = UIColor(hex: color)
        
        
        ImageView.isUserInteractionEnabled = true
        ImageView.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(imagePicker)))
        
        
        
        SignUp.backgroundColor = UIColor(hex: color)
        Cancel.backgroundColor = UIColor(hex: color)
        
        SignUp.addTarget(self, action: #selector(signUpEvent), for: .touchUpInside)
        Cancel.addTarget(self, action: #selector(cancelEvent), for: .touchUpInside)
    }
    
    
    @objc func signUpEvent(){
        Auth.auth().createUser(withEmail: Email.text!, password: Password.text!) { (user,error) in
            
            let uid = user?.user.uid
            let filename = NSUUID().uuidString
            
            guard let image = self.ImageView.image!.jpegData(compressionQuality: 0.5) else { return }
            let ref = Storage.storage().reference(withPath: "/userImages/\(filename)")
            
            Storage.storage().reference().child("userImages").child(uid!).putData(image, metadata: nil, completion:  { (data, error) in
                
                ref.putData(image, metadata: nil) { _, error in
                    if let error = error {
                        print("DEBUG: Failed to upload image \(error.localizedDescription)")
                        return
                    }
                    
                    print("Image Upload")
                    
                    ref.downloadURL { url, _ in
                        guard let imageUrl = url?.absoluteString else { return }
                        Database.database().reference().child("users").child(uid!).setValue(
                            [
                            "name":self.Name.text!,
                            "profileImageUrl": imageUrl
                            ]
                        )
                    }
                }
                
            })
            
           
        }
    }
    
    @objc func cancelEvent(){
        self.dismiss(animated: true, completion: nil)
    }

    
    @objc func imagePicker(){
        let imagePicker = UIImagePickerController()
        imagePicker.delegate = self
        imagePicker.allowsEditing = true
        imagePicker.sourceType = UIImagePickerController.SourceType.photoLibrary
        
        self.present(imagePicker, animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        
        ImageView.image = info[UIImagePickerController.InfoKey.originalImage] as! UIImage
        
        dismiss(animated: true, completion: nil)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
